"use client";

import { Navbar } from "@/components/Navbar";
import { ClaimsPanel } from "@/components/ClaimsPanel";

export default function HomePage() {
  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />

      <main className="flex-grow pt-20 pb-12 px-4 md:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-8 animate-fade-in">
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold mb-4">
              FactAnchor
            </h1>
            <p className="text-lg md:text-xl text-muted-foreground max-w-2xl mx-auto">
              Web-grounded claim resolution on GenLayer.
              <br />
              Submit a checkable claim, and validator consensus settles it — no oracle.
            </p>
          </div>

          <div className="animate-slide-up">
            <ClaimsPanel />
          </div>

          <div
            className="mt-8 glass-card p-6 md:p-8 animate-fade-in"
            style={{ animationDelay: "200ms" }}
          >
            <h2 className="text-2xl font-bold mb-4">How it Works</h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="space-y-2">
                <div className="text-accent font-bold text-lg">1. Submit a Claim</div>
                <p className="text-sm text-muted-foreground">
                  Connect your wallet and submit a plain-English, checkable claim
                  along with a fixed source URL validators will check.
                </p>
              </div>
              <div className="space-y-2">
                <div className="text-accent font-bold text-lg">2. Resolve It</div>
                <p className="text-sm text-muted-foreground">
                  Validators independently fetch the source and judge it with an
                  LLM. Only the objective verdict is compared across nodes.
                </p>
              </div>
              <div className="space-y-2">
                <div className="text-accent font-bold text-lg">3. Read the Verdict</div>
                <p className="text-sm text-muted-foreground">
                  Once consensus is reached, the claim's status and reasoning are
                  readable by anyone, permanently, on-chain.
                </p>
              </div>
            </div>
          </div>
        </div>
      </main>

      <footer className="border-t border-white/10 py-2">
        <div className="max-w-7xl mx-auto px-4 md:px-6 lg:px-8">
          <div className="flex items-center justify-center gap-6 text-sm text-muted-foreground">
            <a
              href="https://genlayer.com"
              target="_blank"
              rel="noopener noreferrer"
              className="hover:text-accent transition-colors"
            >
              Powered by GenLayer
            </a>
            <a
              href="https://studio.genlayer.com"
              target="_blank"
              rel="noopener noreferrer"
              className="hover:text-accent transition-colors"
            >
              Studio
            </a>
            <a
              href="https://docs.genlayer.com"
              target="_blank"
              rel="noopener noreferrer"
              className="hover:text-accent transition-colors"
            >
              Docs
            </a>
          </div>
        </div>
      </footer>
    </div>
  );
}
