"use client";

import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useMemo, useState } from "react";
import FactAnchor from "../contracts/FactAnchor";
import { getContractAddress, getStudioUrl } from "../genlayer/client";
import type { FeePresetLevel } from "../genlayer/fees";
import { useWallet } from "../genlayer/wallet";
import { success, error, configError } from "../utils/toast";
import type { Claim } from "../contracts/types";

/**
 * Hook to get the FactAnchor contract instance.
 * Returns null if contract address is not configured.
 * Read-only calls (getClaim, getTotalClaims) work without a connected wallet;
 * write calls (submitClaim, resolveClaim) require one.
 */
export function useFactAnchorContract(): FactAnchor | null {
  const { address } = useWallet();
  const contractAddress = getContractAddress();
  const studioUrl = getStudioUrl();

  const contract = useMemo(() => {
    if (!contractAddress) {
      configError(
        "Setup Required",
        "Contract address not configured. Please set NEXT_PUBLIC_CONTRACT_ADDRESS in your .env file.",
        {
          label: "Setup Guide",
          onClick: () => window.open("/docs/setup", "_blank"),
        }
      );
      return null;
    }

    return new FactAnchor(contractAddress, address, studioUrl);
  }, [contractAddress, address, studioUrl]);

  return contract;
}

/**
 * Hook to fetch a single claim by ID
 */
export function useClaim(claimId: number | null) {
  const contract = useFactAnchorContract();

  return useQuery<Claim | null, Error>({
    queryKey: ["claim", claimId],
    queryFn: () => {
      if (!contract || claimId === null) {
        return Promise.resolve(null);
      }
      return contract.getClaim(claimId);
    },
    refetchOnWindowFocus: true,
    staleTime: 2000,
    enabled: claimId !== null && !!contract,
  });
}

/**
 * Hook to fetch the total number of claims submitted
 */
export function useTotalClaims() {
  const contract = useFactAnchorContract();

  return useQuery<number, Error>({
    queryKey: ["totalClaims"],
    queryFn: () => {
      if (!contract) {
        return Promise.resolve(0);
      }
      return contract.getTotalClaims();
    },
    refetchOnWindowFocus: true,
    staleTime: 2000,
    enabled: !!contract,
  });
}

/**
 * Hook to submit a new claim
 */
export function useSubmitClaim() {
  const contract = useFactAnchorContract();
  const { address } = useWallet();
  const queryClient = useQueryClient();
  const [isSubmitting, setIsSubmitting] = useState(false);

  const mutation = useMutation({
    mutationFn: async ({
      claimText,
      sourceUrl,
      feePresetLevel,
    }: {
      claimText: string;
      sourceUrl: string;
      feePresetLevel?: FeePresetLevel;
    }) => {
      if (!contract) {
        throw new Error(
          "Contract not configured. Please set NEXT_PUBLIC_CONTRACT_ADDRESS in your .env file."
        );
      }
      if (!address) {
        throw new Error("Wallet not connected. Please connect your wallet to submit a claim.");
      }
      setIsSubmitting(true);
      const feePreset = await contract.estimateSubmitClaimFees(
        claimText,
        sourceUrl,
        feePresetLevel ?? "standard"
      );
      return contract.submitClaim(claimText, sourceUrl, feePreset);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["totalClaims"] });
      setIsSubmitting(false);
      success("Claim submitted successfully!", {
        description: "Your claim has been recorded on the blockchain.",
      });
    },
    onError: (err: any) => {
      console.error("Error submitting claim:", err);
      setIsSubmitting(false);
      error("Failed to submit claim", {
        description: err?.message || "Please try again.",
      });
    },
  });

  return {
    ...mutation,
    isSubmitting,
    submitClaim: mutation.mutate,
    submitClaimAsync: mutation.mutateAsync,
  };
}

/**
 * Hook to resolve a claim via validator consensus
 */
export function useResolveClaim() {
  const contract = useFactAnchorContract();
  const { address } = useWallet();
  const queryClient = useQueryClient();
  const [isResolving, setIsResolving] = useState(false);
  const [resolvingClaimId, setResolvingClaimId] = useState<number | null>(null);

  const mutation = useMutation({
    mutationFn: async (claimId: number) => {
      if (!contract) {
        throw new Error(
          "Contract not configured. Please set NEXT_PUBLIC_CONTRACT_ADDRESS in your .env file."
        );
      }
      if (!address) {
        throw new Error("Wallet not connected. Please connect your wallet to resolve a claim.");
      }
      setIsResolving(true);
      setResolvingClaimId(claimId);
      const feePreset = await contract.estimateResolveClaimFees(claimId);
      return contract.resolveClaim(claimId, feePreset);
    },
    onSuccess: (_data, claimId) => {
      queryClient.invalidateQueries({ queryKey: ["claim", claimId] });
      queryClient.invalidateQueries({ queryKey: ["totalClaims"] });
      setIsResolving(false);
      setResolvingClaimId(null);
      success("Claim resolved!", {
        description: "Validator consensus has settled the verdict.",
      });
    },
    onError: (err: any) => {
      console.error("Error resolving claim:", err);
      setIsResolving(false);
      setResolvingClaimId(null);
      error("Failed to resolve claim", {
        description: err?.message || "Please try again.",
      });
    },
  });

  return {
    ...mutation,
    isResolving,
    resolvingClaimId,
    resolveClaim: mutation.mutate,
    resolveClaimAsync: mutation.mutateAsync,
  };
}
