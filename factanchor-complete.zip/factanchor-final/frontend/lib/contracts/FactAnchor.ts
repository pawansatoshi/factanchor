import { createClient } from "genlayer-js";
import { studionet } from "genlayer-js/chains";
import type { Claim, TransactionReceipt } from "./types";
import {
  estimateWriteFeePreset,
  feePresetToTransactionFees,
  type FeePresetEstimate,
  type FeePresetLevel,
} from "../genlayer/fees";

/**
 * FactAnchor contract class for interacting with the deployed FactAnchor
 * Intelligent Contract. Structured identically to the boilerplate's
 * FootballBets.ts (the boilerplate's reference contract class) so it drops
 * into the same hooks/components pattern.
 */
class FactAnchor {
  private contractAddress: `0x${string}`;
  private client: any;
  private studioUrl?: string;

  constructor(
    contractAddress: string,
    address?: string | null,
    studioUrl?: string
  ) {
    this.contractAddress = contractAddress as `0x${string}`;
    this.studioUrl = studioUrl;

    const config: any = {
      chain: studionet,
    };

    if (address) {
      config.account = address as `0x${string}`;
    }

    if (studioUrl) {
      config.endpoint = studioUrl;
    }

    this.client = createClient(config);
  }

  /**
   * Update the address used for transactions
   */
  updateAccount(address: string): void {
    const config: any = {
      chain: studionet,
      account: address as `0x${string}`,
    };

    if (this.studioUrl) {
      config.endpoint = this.studioUrl;
    }

    this.client = createClient(config);
  }

  async estimateSubmitClaimFees(
    claimText: string,
    sourceUrl: string,
    level: FeePresetLevel = "standard"
  ): Promise<FeePresetEstimate | undefined> {
    return estimateWriteFeePreset(
      this.client,
      {
        address: this.contractAddress,
        functionName: "submit_claim",
        args: [claimText, sourceUrl],
      },
      level,
    );
  }

  async estimateResolveClaimFees(
    claimId: number,
    level: FeePresetLevel = "standard"
  ): Promise<FeePresetEstimate | undefined> {
    return estimateWriteFeePreset(
      this.client,
      {
        address: this.contractAddress,
        functionName: "resolve_claim",
        args: [claimId],
      },
      level,
    );
  }

  /**
   * Get a single claim's current state
   * @param claimId - ID of the claim to fetch
   */
  async getClaim(claimId: number): Promise<Claim | null> {
    try {
      const result: any = await this.client.readContract({
        address: this.contractAddress,
        functionName: "get_claim",
        args: [claimId],
      });

      if (!result) return null;

      return {
        id: claimId,
        claim: result.claim ?? "",
        sourceUrl: result.source_url ?? "",
        status: result.status ?? "unresolved",
        reasoning: result.reasoning ?? "",
      } as Claim;
    } catch (error) {
      console.error("Error fetching claim:", error);
      throw new Error("Failed to fetch claim from contract");
    }
  }

  /**
   * Get the total number of claims submitted so far
   */
  async getTotalClaims(): Promise<number> {
    try {
      const total = await this.client.readContract({
        address: this.contractAddress,
        functionName: "total_claims",
        args: [],
      });

      return Number(total) || 0;
    } catch (error) {
      console.error("Error fetching total claims:", error);
      return 0;
    }
  }

  /**
   * Submit a new claim for resolution
   * @param claimText - Plain-English, checkable claim
   * @param sourceUrl - Fixed source every validator will independently fetch
   */
  async submitClaim(
    claimText: string,
    sourceUrl: string,
    feePreset?: FeePresetEstimate
  ): Promise<TransactionReceipt> {
    try {
      const fees = feePresetToTransactionFees(feePreset);
      const txHash = await this.client.writeContract({
        address: this.contractAddress,
        functionName: "submit_claim",
        args: [claimText, sourceUrl],
        value: BigInt(0),
        ...(fees ? { fees } : {}),
      });

      const receipt = await this.client.waitForTransactionReceipt({
        hash: txHash,
        status: "ACCEPTED" as any,
        retries: 24,
        interval: 5000,
      });

      return receipt as TransactionReceipt;
    } catch (error) {
      console.error("Error submitting claim:", error);
      throw new Error("Failed to submit claim");
    }
  }

  /**
   * Resolve a claim via validator consensus (leader/validator partial
   * field matching over the objective verdict field)
   * @param claimId - ID of the claim to resolve
   */
  async resolveClaim(
    claimId: number,
    feePreset?: FeePresetEstimate
  ): Promise<TransactionReceipt> {
    try {
      const fees = feePresetToTransactionFees(feePreset);
      const txHash = await this.client.writeContract({
        address: this.contractAddress,
        functionName: "resolve_claim",
        args: [claimId],
        value: BigInt(0),
        ...(fees ? { fees } : {}),
      });

      const receipt = await this.client.waitForTransactionReceipt({
        hash: txHash,
        status: "ACCEPTED" as any,
        retries: 24,
        interval: 5000,
      });

      return receipt as TransactionReceipt;
    } catch (error) {
      console.error("Error resolving claim:", error);
      throw new Error("Failed to resolve claim");
    }
  }
}

export default FactAnchor;
