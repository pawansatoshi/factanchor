export interface Claim {
  id: number;
  claim: string;
  sourceUrl: string;
  status: "unresolved" | "true" | "false" | "undetermined";
  reasoning: string;
}

export interface TransactionReceipt {
  hash: string;
  status: string;
  result?: any;
  [key: string]: any;
}
