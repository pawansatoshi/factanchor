"use client";

import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Alert } from "@/components/ui/alert";
import { useWallet } from "@/lib/genlayer/wallet";
import {
  useSubmitClaim,
  useResolveClaim,
  useClaim,
  useTotalClaims,
} from "@/lib/hooks/useFactAnchor";

function StatusBadge({ status }: { status: string }) {
  const variant =
    status === "true" ? "default" : status === "false" ? "destructive" : "secondary";
  return <Badge variant={variant as any}>{status}</Badge>;
}

export function ClaimsPanel() {
  const { address, connectWallet, isLoading } = useWallet();

  const [claimText, setClaimText] = useState("");
  const [sourceUrl, setSourceUrl] = useState("");
  const { submitClaim, isSubmitting } = useSubmitClaim();

  const [resolveId, setResolveId] = useState("");
  const { resolveClaim, isResolving } = useResolveClaim();

  const [lookupId, setLookupId] = useState("");
  const [activeLookupId, setActiveLookupId] = useState<number | null>(null);
  const { data: claim, isLoading: isLoadingClaim } = useClaim(activeLookupId);

  const { data: totalClaims } = useTotalClaims();

  return (
    <div className="space-y-6">
      {!address ? (
        <Button onClick={() => connectWallet()} disabled={isLoading} className="w-full">
          {isLoading ? "Connecting…" : "Connect Wallet"}
        </Button>
      ) : (
        <Alert>
          Connected: {address} · Total claims submitted: {totalClaims ?? "…"}
        </Alert>
      )}

      {/* Submit a claim */}
      <div className="glass-card p-6 space-y-3">
        <h3 className="font-bold text-lg">Submit a claim</h3>
        <div className="space-y-2">
          <Label htmlFor="claimText">Claim</Label>
          <Input
            id="claimText"
            placeholder="e.g. Did the Fed cut rates on July 30 2026?"
            value={claimText}
            onChange={(e) => setClaimText(e.target.value)}
          />
        </div>
        <div className="space-y-2">
          <Label htmlFor="sourceUrl">Source URL</Label>
          <Input
            id="sourceUrl"
            placeholder="https://example.com/news-article"
            value={sourceUrl}
            onChange={(e) => setSourceUrl(e.target.value)}
          />
        </div>
        <Button
          disabled={!address || isSubmitting || !claimText || !sourceUrl}
          onClick={() =>
            submitClaim(
              { claimText, sourceUrl },
              {
                onSuccess: () => {
                  setClaimText("");
                  setSourceUrl("");
                },
              }
            )
          }
          className="w-full"
        >
          {isSubmitting ? "Submitting…" : "Submit Claim"}
        </Button>
      </div>

      {/* Resolve a claim */}
      <div className="glass-card p-6 space-y-3">
        <h3 className="font-bold text-lg">Resolve a claim</h3>
        <div className="space-y-2">
          <Label htmlFor="resolveId">Claim ID</Label>
          <Input
            id="resolveId"
            type="number"
            placeholder="0"
            value={resolveId}
            onChange={(e) => setResolveId(e.target.value)}
          />
        </div>
        <Button
          disabled={!address || isResolving || resolveId === ""}
          onClick={() => resolveClaim(Number(resolveId))}
          className="w-full"
        >
          {isResolving ? "Requesting validator consensus…" : "Resolve Claim"}
        </Button>
      </div>

      {/* Look up a claim */}
      <div className="glass-card p-6 space-y-3">
        <h3 className="font-bold text-lg">Look up a claim</h3>
        <div className="space-y-2">
          <Label htmlFor="lookupId">Claim ID</Label>
          <Input
            id="lookupId"
            type="number"
            placeholder="0"
            value={lookupId}
            onChange={(e) => setLookupId(e.target.value)}
          />
        </div>
        <Button
          variant="outline"
          disabled={lookupId === ""}
          onClick={() => setActiveLookupId(Number(lookupId))}
          className="w-full"
        >
          Get Claim
        </Button>

        {isLoadingClaim && <p className="text-sm text-muted-foreground">Loading…</p>}

        {claim && (
          <div className="mt-2 space-y-2 text-sm">
            <p>
              <span className="text-muted-foreground">Claim:</span> {claim.claim}
            </p>
            <p>
              <span className="text-muted-foreground">Source:</span>{" "}
              <a
                href={claim.sourceUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="text-accent hover:underline"
              >
                {claim.sourceUrl}
              </a>
            </p>
            <p className="flex items-center gap-2">
              <span className="text-muted-foreground">Status:</span>
              <StatusBadge status={claim.status} />
            </p>
            {claim.reasoning && (
              <p>
                <span className="text-muted-foreground">Reasoning:</span> {claim.reasoning}
              </p>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
